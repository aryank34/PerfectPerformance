/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import java.io.*;

/**
 *
 * @author NandiniCreations
 */
public class transfer_data {

    public static void main(String[] args) {
        try {
            BufferedReader file_sup_name = new BufferedReader(new FileReader(new File("SupplierNames.txt")));
            BufferedReader file_sup_loc = new BufferedReader(new FileReader(new File("SupplierLocation.txt")));
            BufferedReader file_sup_func = new BufferedReader(new FileReader(new File("SupplierFunction.txt")));
            BufferedReader file_sup_cost = new BufferedReader(new FileReader(new File("SupplierCost.txt")));
            BufferedReader file_sup_rating = new BufferedReader(new FileReader(new File("SupplierRatings.txt")));
            BufferedReader file_sup_adt = new BufferedReader(new FileReader(new File("SupplierADT.txt")));
            BufferedReader file_sup_esc = new BufferedReader(new FileReader(new File("SupplierEscalations.txt")));
            BufferedReader file_sup_year = new BufferedReader(new FileReader(new File("SupplierYears.txt")));
            BufferedReader file_sup_res = new BufferedReader(new FileReader(new File("SupplierResources.txt")));

            //BufferedWriter file_final_list = new BufferedWriter(new FileWriter(new File("FinalList.txt")));
            //PrintWriter file_final_list = new PrintWriter(new BufferedWriter(new FileWriter(new File("FinalList.txt"))));
            BufferedWriter file_final_list = new BufferedWriter(new FileWriter(new File("FinalList.txt").getAbsoluteFile()));

            System.out.println("Start reading & writing");

            for (int i = 0; i < 500000; i++) {
                String name = file_sup_name.readLine();
                String location = file_sup_loc.readLine();
                String function = file_sup_func.readLine();
                String cost = file_sup_cost.readLine();
                String rating = file_sup_rating.readLine();
                String adt = file_sup_adt.readLine();
                String esc = file_sup_esc.readLine();
                String year = file_sup_year.readLine();
                String resources = file_sup_res.readLine();

                //System.out.println(name+"\t"+location+"\t"+function);
                String writeText = "Supplier Name: " + name + "\nLocation: " + location + "\nFunction: " + function
                        + "\nAvg. Cost: " + cost + "\nRating: " + rating + "\nAverage Delivery Time: " + adt + "\nNumber of Escalations: " + esc
                        + "\nYear: " + year + "\nResources: " + resources + "\n\n";
                //System.out.println(writeText);
                file_final_list.write(writeText);
                System.out.println("file written: line " + (i + 1));

            }
            file_final_list.close();
            file_sup_name.close();
            file_sup_loc.close();
            file_sup_func.close();
            file_sup_cost.close();
            file_sup_rating.close();
            file_sup_adt.close();
            file_sup_esc.close();
            file_sup_year.close();
            file_sup_res.close();
            //System.out.println(al);
            //check final list
            /*
            BufferedReader readFinal = new BufferedReader(new FileReader(new File("FinalList.txt")));
            System.out.println("Reading Final List : ");
            while (readFinal.readLine() != null) {
                System.out.println(readFinal.readLine());
            }*/

        } catch (Exception e) {
            System.out.println("Error in main class : " + e.getMessage());
        }
    }

}
