/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import java.io.*;
import java.util.ArrayList;

public class PerfectPerformance {

    static ArrayList<String> al = new ArrayList<>();
    static ArrayList<String> final_list = new ArrayList<>();

    public static void main(String[] args) {
        double esc_rate;
        double eff;
        double ratio;
        double min = 10000;
        double max = 0;
        try {
            int cost, rating, adt, esc;

            BufferedReader readList = new BufferedReader(new FileReader(new File("FinalList.txt")));
            for (int i = 1; i <= 500000; i++) {
                //while(readList.readLine()!=null){
                for (int j = 1; j <= 9; j++) {
                    String[] temp = readList.readLine().split(": ");
                    al.add(temp[1]);
                }
                //System.out.println(al);
                esc = Integer.parseInt(al.get(6));
                //System.out.println(esc);
                cost = Integer.parseInt(al.get(3).replace("k", "000"));
                //System.out.println(cost);
                esc_rate = esc * 100;
                esc_rate /= cost;
                //System.out.println(esc_rate);

                adt = Integer.parseInt(al.get(5));
                eff = 100;
                eff /= adt;
                //System.out.println(eff);

                rating = Integer.parseInt(al.get(4));
                //System.out.println(rating);

                ratio = (esc_rate) / (eff + rating);
                //System.out.println(ratio);
                if (ratio < min) {
                    max = rating;
                    min = ratio;
                    final_list.removeAll(final_list);
                    for (String s : al) {
                        final_list.add(s);
                    }
                    //System.out.println(final_list);
                } else if (ratio == min) {
                    if (rating >= max) {
                        max = rating;
                        min = ratio;
                        final_list.removeAll(final_list);
                        for (String s : al) {
                            final_list.add(s);
                        }
                    }
                }

                //System.out.println(al);
                al.removeAll(al);
                readList.readLine();

            }
            System.out.println("Found Perfect Supplier");
            String writeText = "Supplier Name: " + final_list.get(0) + "\nLocation: " + final_list.get(1) + "\nFunction: " + final_list.get(2)
                    + "\nAvg. Cost: " + final_list.get(3) + "\nRating: " + final_list.get(4) + "\nAverage Delivery Time: " + final_list.get(5) + 
                    "\nNumber of Escalations: " + final_list.get(6)
                    + "\nYear: " + final_list.get(7) + "\nResources: " + final_list.get(8) + "\n\n";
            System.out.println(writeText);
            File file = new File("PerfectPerformance.txt");
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(writeText);
            bw.close();
            readList.close();

            System.out.println("Text Written. Done");

        } catch (IOException e) {
            System.out.println("Error in main class : " + e.getMessage());
        }
    }

}
